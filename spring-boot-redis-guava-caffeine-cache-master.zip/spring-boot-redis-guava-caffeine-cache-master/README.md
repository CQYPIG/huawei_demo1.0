## springboot使用redis做数据缓存

* [spring boot caffeine cache 缓存学习](http://blog.csdn.net/hy245120020/article/details/78065698)
* [spring boot guava cache 缓存学习](http://blog.csdn.net/hy245120020/article/details/78065676)
* [spring boot redis cache 缓存学习](http://blog.csdn.net/hy245120020/article/details/78065654)
* [guava和caffeine性能测试](http://blog.csdn.net/hy245120020/article/details/78080686)
* [springboot2.x版本redis缓存学习](https://blog.csdn.net/hy245120020/article/details/89028833)
* [springboot2.x版本多个redis实例配置学习](https://blog.csdn.net/hy245120020/article/details/89029111)
