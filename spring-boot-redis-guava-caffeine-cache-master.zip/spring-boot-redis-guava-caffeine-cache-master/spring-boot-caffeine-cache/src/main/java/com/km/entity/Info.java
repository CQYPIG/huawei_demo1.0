package com.km.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <p></p>
 * Created by zhezhiyong@163.com on 2017/9/22.
 */
@Data
@AllArgsConstructor
public class Info {
    private String phone;
    private String address;

}
