package com.cpl.tsl.demo;

/**
 * Demo类
 *
 * @author: lll
 * @date: 2022年02月11日 15:02:03
 */
public class Demo {
    public static void main(String[] args) {
        //123456
        System.out.println("hello world");
    }
}
